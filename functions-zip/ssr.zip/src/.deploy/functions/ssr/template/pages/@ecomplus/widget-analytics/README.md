# Widget Analytics

[![npm version](https://img.shields.io/npm/v/@ecomplus/widget-analytics.svg)](https://www.npmjs.org/@ecomplus/widget-analytics)
[![License MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Storefront plugin to handle GA Universal Analytics (gtag.js) with page views and ecommerce events

[CHANGELOG](https://github.com/ecomplus/storefront/blob/master/@ecomplus/widget-analytics/CHANGELOG.md)
